CREATE FUNCTION [dbo].[GetCustomerInvoiceYear]
(
	@id int
)
RETURNS Char(4)
AS
BEGIN
DECLARE @result Char(4);
SELECT @result= CONVERT(Char,DATEPART(Year, [TransDate])) 
FROM CustomerInvoice
WHERE id = @id;
	RETURN @result
END
go

