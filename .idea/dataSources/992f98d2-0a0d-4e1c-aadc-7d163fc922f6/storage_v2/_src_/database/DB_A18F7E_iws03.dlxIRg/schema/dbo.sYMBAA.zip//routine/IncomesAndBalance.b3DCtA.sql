
CREATE PROCEDURE [dbo].[IncomesAndBalance]
@class NVARCHAR(50),
@period	NVARCHAR(6), 
@companyid NVARCHAR(6)

AS 
	SET NOCOUNT ON;

DECLARE @Balance Table	
(
    [ID]           INT            IDENTITY (1, 1) NOT NULL,
    [ClassId]      NVARCHAR (50)  NULL,
    [ClassName]    NVARCHAR (150) NULL,
    [SubClassId]   NVARCHAR (50)  NULL,
    [SubClassName] NVARCHAR (150) NULL,
    [AccountId]    NVARCHAR (50)  NULL,
    [AccountName]  NVARCHAR (150) NULL,
    [TDebit]       MONEY          DEFAULT (0) NOT NULL,
    [TCredit]      MONEY          DEFAULT (0) NOT NULL,
    [SDebit]       MONEY          DEFAULT ((0)) NOT NULL,
    [SCredit]      MONEY          DEFAULT ((0)) NOT NULL,
    [Currency]     NVARCHAR (50)  NULL,
    [Balance]      MONEY          DEFAULT ((0)) NOT NULL,
    [CompanyId]    NVARCHAR (50)  NOT NULL,
    [IsBalance]    BIT            NULL,
	[IsDebit]      BIT            NULL
)

DECLARE @classId NVARCHAR(50)
DECLARE @className NVARCHAR(150)
DECLARE @subClassId NVARCHAR(50)
DECLARE @subClassName NVARCHAR(150)
DECLARE @accountId NVARCHAR(50)
DECLARE @accountName NVARCHAR(150)
DECLARE @checkclass NVARCHAR(50)


delete from @Balance


DECLARE fcursor CURSOR FOR  

SELECT ChildId, ChildName, ParentId, ParentName FROM GetChild(@class, @companyid);

OPEN fcursor   
FETCH NEXT FROM fcursor INTO @subClassId, @subClassName, @classId, @className

WHILE @@FETCH_STATUS = 0   
BEGIN

INSERT @Balance (AccountId, AccountName, TDebit, TCredit, Currency, CompanyId)
SELECT AccountId, Name, TDebit, TCredit, Currency, @companyid AS CompanyID
FROM dbo.GetAccountBalances(@subClassId, @period, @companyid)

Update @Balance Set ClassId=@classId, ClassName=@className, SubClassId=@subClassId, SubClassName=@subClassName 
		WHERE ClassName IS NULL;

UPDATE       @Balance
SET                Isdebit = a.IsDebit
FROM            Account a INNER JOIN
                         @Balance b ON a.id = b.AccountId AND a.CompanyID = b.CompanyId;

FETCH NEXT FROM fcursor
INTO @subClassId, @subClassName, @classId, @className

END   

CLOSE fcursor   

DEALLOCATE fcursor

SELECT        ClassId, ClassName, SubClassId, SubClassName, AccountId, AccountName, SUM(TDebit) AS TDebit, SUM(TCredit) AS TCredit, Currency, IsDebit
FROM            @Balance
GROUP BY ClassId, ClassName, SubClassId, SubClassName, AccountId, AccountName, Currency, IsDebit

go

