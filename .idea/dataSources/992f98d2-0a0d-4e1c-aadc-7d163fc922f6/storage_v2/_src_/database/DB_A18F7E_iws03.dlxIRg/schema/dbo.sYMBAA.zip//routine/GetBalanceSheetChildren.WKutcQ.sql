

CREATE FUNCTION [dbo].[GetBalanceSheetChildren](@classId NVARCHAR(50), 
@companyid NVARCHAR(50), @isBalanceSheetAccount BIT)  

RETURNS TABLE  
AS  
RETURN  

WITH children AS
(
    SELECT id, name, IsBalanceSheetAccount
        FROM Account WHERE ParentId = @classId AND CompanyID=@companyid
    UNION ALL
    SELECT Account.id, Account.name, Account.IsBalanceSheetAccount 
	FROM Account  JOIN children  ON Account.ParentId = children.Id
)
SELECT id,name
    FROM children
	WHERE IsBalanceSheetAccount = @isBalanceSheetAccount

go

