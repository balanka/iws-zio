
CREATE FUNCTION [dbo].[GetMasterComptaTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM([amount]) FROM DetailCompta
WHERE transid = @id;
	RETURN @result
END
go

