
CREATE PROCEDURE [dbo].[NewAccountBalance]
@class NVARCHAR(50),
@period	NVARCHAR(6), 
@companyid NVARCHAR(6),
@isBalance BIT

AS 
	SET NOCOUNT ON;

DECLARE @Balance Table	
(
    [ID]           INT            IDENTITY (1, 1) NOT NULL,
    [ClassId]      NVARCHAR (50)  NULL,
    [ClassName]    NVARCHAR (150) NULL,
    [SubClassId]   NVARCHAR (50)  NULL,
    [SubClassName] NVARCHAR (150) NULL,
    [AccountId]    NVARCHAR (50)  NULL,
    [AccountName]  NVARCHAR (150) NULL,
    [TDebit]       MONEY          NULL,
    [TCredit]      MONEY          NULL,
    [SDebit]       MONEY          NULL,
    [SCredit]      MONEY          NULL,
    [Currency]     NVARCHAR (50)  NULL,
    [Balance]      MONEY          DEFAULT ((0)) NULL,
    [CompanyId]    NVARCHAR (50)  NOT NULL,
    [IsBalance]    BIT            NULL,
	[IsDebit]      BIT            NULL
)

DECLARE @classId NVARCHAR(50)
DECLARE @className NVARCHAR(150)
DECLARE @subClassId NVARCHAR(50)
DECLARE @subClassName NVARCHAR(150)
DECLARE @accountId NVARCHAR(50)
DECLARE @accountName NVARCHAR(150)

DECLARE fcursor CURSOR FOR  

SELECT ChildId, ChildName, ParentId, ParentName FROM GetChild(@class, @companyid) 

OPEN fcursor   
FETCH NEXT FROM fcursor INTO @subClassId, @subClassName, @classId, @className

WHILE @@FETCH_STATUS = 0   
BEGIN

INSERT @Balance (AccountId, AccountName, TDebit, TCredit, SDebit, SCredit, IsDebit, Currency, CompanyId)  
SELECT g.AccountId, g.Name, Debit+IDebit, Credit+ICredit, IDebit, ICredit, a.IsDebit, g.Currency, @companyid AS CompanyID
FROM dbo.GetNewAccountBalance(@subClassId, @period, @companyid) g INNER JOIN Account	a ON g.AccountId = a.id;

Update @Balance Set ClassId=@classId, ClassName=@className, SubClassId=@subClassId, SubClassName=@subClassName 
		WHERE ClassName IS NULL;

Update @Balance Set Balance = IIF(IsDebit=1, TDebit-TCredit, TCredit-TDebit) WHERE CompanyId=@companyid;

FETCH NEXT FROM fcursor INTO @subClassId, @subClassName, @classId, @className

END

CLOSE fcursor   

DEALLOCATE fcursor


UPDATE       @Balance
SET                IsBalance = IIF(@isBalance = 1, a.IsBalanceSheetAccount, a.IsResultAccount)
FROM            Account a INNER JOIN
                         @Balance b ON a.id = b.AccountId AND a.CompanyID = b.CompanyId
                         
DECLARE scursor CURSOR FOR  

SELECT id, name 
FROM [GetResultBalanceSheetChildren](@class, @companyid, @isBalance)--1

Open scursor 

FETCH NEXT FROM scursor
INTO @accountId, @accountName

WHILE @@FETCH_STATUS = 0   
BEGIN

INSERT INTO @Balance
            (ClassId, ClassName, SubClassId, SubClassName,TDebit,TCredit,SDebit,SCredit,Balance, Currency, CompanyId, IsBalance)
SELECT        ClassId, ClassName, SubClassId, SubClassName, SUM(TDebit) AS TDebit, SUM(TCredit) AS TCredit, SUM(SDebit) AS SDebit, SUM(SCredit) AS SCredit, SUM(Balance) AS Balance, Currency, CompanyId, 1
FROM            @Balance
WHERE        (AccountId IN
					(SELECT     id
							FROM      dbo.GetChildren(@accountId, @companyid)))
GROUP BY ClassId, CompanyId, ClassName, SubClassId, SubClassName, Currency, IsBalance
HAVING IsBalance=0;

UPDATE @Balance set AccountId=@accountId, AccountName=@accountName WHERE AccountId IS NULL;

UPDATE @Balance Set IsBalance=1 WHERE AccountId=@accountId;

FETCH NEXT FROM scursor INTO @accountId, @accountName
END
CLOSE scursor   
DEALLOCATE scursor

SELECT * FROM @Balance where CompanyId=@companyid AND IsBalance=1 ORDER BY ID
go

