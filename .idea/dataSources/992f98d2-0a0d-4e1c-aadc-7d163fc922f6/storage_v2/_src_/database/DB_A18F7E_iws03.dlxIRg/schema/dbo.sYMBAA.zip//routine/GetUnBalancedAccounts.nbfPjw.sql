CREATE FUNCTION [dbo].[GetUnBalancedAccounts](
@id NVARCHAR(50), 
@oyear NVARCHAR(4),  
@companyid NVARCHAR(6))
RETURNS TABLE  
AS  
RETURN  

SELECT   P.oYear, P.AccountId, Name, (Debit+IDebit) As Debit, (Credit+ICredit) As Credit, Currency
FROM PeriodicAccountBalance P
INNER JOIN (SELECT AccountId, MAX(CONVERT(int,periode)) AS Periode 
			FROM PeriodicAccountBalance 
			WHERE   convert(int, oYear) = @oyear AND CompanyID = @companyid	--(Debit != 0 OR Credit != 0) AND
			GROUP By AccountId) AS T ON T.AccountId = P.AccountId AND T.Periode = P.Periode
WHERE		(P.AccountId IN
                             (SELECT        id
                               FROM            dbo.GetChildren(@id, @companyid)))
AND			(Debit+IDebit) != (Credit+ICredit)

go

