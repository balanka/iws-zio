


CREATE FUNCTION [dbo].[GetLineGoodReceivingNet]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=ROUND((price * quantity), 2)
FROM            LineGoodReceiving 
						 WHERE id= @id;
	RETURN @result
END
go

