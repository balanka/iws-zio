

CREATE FUNCTION [dbo].[GetLineSalesInvoiceVAT]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=ROUND((price * quantity *  Vat), 2)
FROM            LineSalesInvoice
						 WHERE id= @id;
	RETURN @result
END
go

