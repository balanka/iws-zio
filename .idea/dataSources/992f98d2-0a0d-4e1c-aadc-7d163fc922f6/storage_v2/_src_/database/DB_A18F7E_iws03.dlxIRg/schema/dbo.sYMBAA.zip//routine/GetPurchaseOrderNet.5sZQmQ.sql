
CREATE FUNCTION [dbo].[GetPurchaseOrderNet]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=oTotal-oVat
FROM            PurchaseOrder 
WHERE id = @id;
	RETURN @result
END
go

