
CREATE FUNCTION [dbo].[GetDetailLogisticNet]
(
	@id int
)
RETURNS MONEY
AS
BEGIN
	DECLARE @result MONEY;
SELECT @result=ROUND((price * quantity),2)
FROM            DetailLogistic 
WHERE id = @id;
	RETURN @result

END
go

