


CREATE FUNCTION [dbo].[GetLineBillOfDeliveryVAT]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=ROUND((price * quantity * Vat), 2)
FROM            LineBillOfDelivery
						 WHERE id= @id;
	RETURN @result
END
go

