CREATE FUNCTION [dbo].[GetInventoryInvoiceMonth]
(
	@id int
)
RETURNS char(2)
AS
BEGIN
DECLARE @result Char(2);
SELECT @result= CASE 
                WHEN (CONVERT(Int,LEN(CONVERT(Char,DATEPART(Month, [TransDate]))))) = 1  
				THEN N'0' + (CONVERT(Char,DATEPART(Month, [TransDate])))
                ELSE CONVERT(Char,DATEPART(Month, [TransDate]))
             END 
FROM InventoryInvoice
WHERE id = @id;
	RETURN @result
END;
go

