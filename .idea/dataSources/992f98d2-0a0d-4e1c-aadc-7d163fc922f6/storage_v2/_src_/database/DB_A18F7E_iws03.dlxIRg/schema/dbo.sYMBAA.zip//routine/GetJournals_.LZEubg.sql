

CREATE FUNCTION [dbo].[GetJournals](@start NVARCHAR(6), @end NVARCHAR(6), @uiculture NVARCHAR(5), @companyid NVARCHAR(6))  
RETURNS TABLE  
AS  
RETURN  
		SELECT        Journal.ID, Journal.ItemID, Journal.OID, Localization.LocalName, Journal.CustSupplierID, Journal.TransDate, Journal.Periode, Journal.OYear, 
					Journal.oMonth, Journal.Account, Journal.AccountName, Journal.OAccount, Journal.OAccountName, Journal.Amount, Journal.Side, Journal.Currency, 
                         Journal.CompanyID, Journal.CustSupplierName AS Owner
		FROM            Journal INNER JOIN
                         Localization ON Journal.ItemType = Localization.ItemName
		WHERE        (Journal.Periode BETWEEN @start AND @end) AND (Localization.UICulture = @uiculture) AND (Journal.CompanyID=@companyid)
go

