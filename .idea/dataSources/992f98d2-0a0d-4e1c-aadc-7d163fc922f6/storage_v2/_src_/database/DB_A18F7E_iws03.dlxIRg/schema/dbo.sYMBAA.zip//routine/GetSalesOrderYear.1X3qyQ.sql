CREATE FUNCTION [dbo].[GetSalesOrderYear]
(
	@id int
)
RETURNS Char(4)
AS
BEGIN
DECLARE @result Char(4);
SELECT @result= CONVERT(Char,DATEPART(Year, [TransDate])) 
FROM SalesOrder
WHERE id = @id;
	RETURN @result
END
go

