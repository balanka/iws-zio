

CREATE FUNCTION [dbo].[GetSalesInvoiceVAT]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineVAT)
FROM            LineSalesInvoice 
WHERE transid = @id;
	RETURN @result
END
go

