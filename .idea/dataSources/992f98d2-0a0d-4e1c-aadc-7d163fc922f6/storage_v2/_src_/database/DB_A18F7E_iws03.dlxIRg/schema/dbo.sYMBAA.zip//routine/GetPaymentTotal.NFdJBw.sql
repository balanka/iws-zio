CREATE FUNCTION [dbo].[GetPaymentTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM([amount]) FROM LinePayment
WHERE transid = @id;
	RETURN @result
END
go

