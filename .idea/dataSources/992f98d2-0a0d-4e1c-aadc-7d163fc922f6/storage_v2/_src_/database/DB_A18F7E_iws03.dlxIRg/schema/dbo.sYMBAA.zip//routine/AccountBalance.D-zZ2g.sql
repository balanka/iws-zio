
CREATE PROCEDURE [dbo].[AccountBalance]
@class NVARCHAR(50),
@start	NVARCHAR(6), 
@companyid NVARCHAR(6)

AS 
	SET NOCOUNT ON;

DECLARE @Balance Table	
(
    [ID]           INT            IDENTITY (1, 1) NOT NULL,
    [ClassId]      NVARCHAR (50)  NULL,
    [ClassName]    NVARCHAR (150) NULL,
    [SubClassId]   NVARCHAR (50)  NULL,
    [SubClassName] NVARCHAR (150) NULL,
    [AccountId]    NVARCHAR (50)  NULL,
    [AccountName]  NVARCHAR (150) NULL,
    [TDebit]       MONEY          NULL,
    [TCredit]      MONEY          NULL,
    [SDebit]       MONEY          NULL,
    [SCredit]      MONEY          NULL,
    [Currency]     NVARCHAR (50)  NULL,
    [Balance]      MONEY          DEFAULT ((0)) NULL,
    [CompanyId]    NVARCHAR (50)  NOT NULL,
    [IsBalance]    BIT            NULL,
	[IsDebit]      BIT            NULL
)

DECLARE @classId NVARCHAR(50)
DECLARE @className NVARCHAR(150)
DECLARE @subClassId NVARCHAR(50)
DECLARE @subClassName NVARCHAR(150)
DECLARE @accountId NVARCHAR(50)
DECLARE @accountName NVARCHAR(150)
DECLARE @checkclass NVARCHAR(50)


DECLARE fcursor CURSOR FOR  

SELECT ChildId, ChildName, ParentId, ParentName FROM GetChild(@class, @companyid) 

OPEN fcursor   
FETCH NEXT FROM fcursor INTO @subClassId, @subClassName, @classId, @className

WHILE @@FETCH_STATUS = 0   
BEGIN

INSERT @Balance (AccountId, AccountName, TDebit, TCredit, SDebit, SCredit, Currency, CompanyId)
SELECT AccountId, Name, TDebit, TCredit, SDebit, SCredit, Currency, @companyid AS CompanyID
FROM dbo.GetAccountBalances(@subClassId, @start, @companyid)

Update @Balance Set ClassId=@classId, ClassName=@className, SubClassId=@subClassId, SubClassName=@subClassName 
		WHERE ClassName IS NULL;

UPDATE       @Balance
SET                Isdebit = a.IsDebit
FROM            Account a INNER JOIN
                         @Balance b ON a.id = b.AccountId AND a.CompanyID = b.CompanyId;


FETCH NEXT FROM fcursor
INTO @subClassId, @subClassName, @classId, @className

END   

CLOSE fcursor   

DEALLOCATE fcursor

--balance sheet
SET @checkclass = (SELECT BalanceSheet  FROM Company WHERE BalanceSheet=@class AND id = @companyId);
if (@checkclass = @class)
BEGIN

UPDATE       @Balance
SET                IsBalance = a.IsBalanceSheetAccount
FROM            Account a INNER JOIN
                         @Balance b ON a.id = b.AccountId AND a.CompanyID = b.CompanyId;

DECLARE scursor CURSOR FOR  

SELECT id, name 
FROM GetBalanceSheetChildren(@class, @companyid, 1) 

Open scursor 

FETCH NEXT FROM scursor
INTO @accountId, @accountName

WHILE @@FETCH_STATUS = 0   
BEGIN

INSERT INTO @Balance
            (ClassId, ClassName, SubClassId, SubClassName,TDebit,TCredit,SDebit,SCredit,Balance, Currency, CompanyId, IsBalance)
SELECT        ClassId, ClassName, SubClassId, SubClassName, SUM(TDebit) AS TDebit, SUM(TCredit) AS TCredit, SUM(SDebit) AS SDebit, 
				SUM(SCredit) AS SCredit, SUM(Balance) AS Balance, Currency, CompanyId, 1
FROM            @Balance
WHERE        (AccountId IN
					(SELECT     id
							FROM      dbo.GetChildren(@accountId, @companyid)))
GROUP BY ClassId, CompanyId, ClassName, SubClassId, SubClassName, Currency, IsBalance
HAVING IsBalance=0;

UPDATE @Balance set AccountId=@accountId, AccountName=@accountName WHERE AccountId IS NULL;

UPDATE @Balance Set IsBalance=1 WHERE AccountId=@accountId;

FETCH NEXT FROM scursor

INTO @accountId, @accountName
END

CLOSE scursor   

DEALLOCATE scursor
END

--IF @isBalance=0--Incomes sheet
SET @checkclass = (SELECT IncomesStatement  FROM Company WHERE IncomesStatement=@class AND id = @companyId);
if (@checkclass = @class)
BEGIN

UPDATE       @Balance
SET                IsBalance = a.IsResultAccount
FROM            Account a INNER JOIN
                         @Balance b ON a.id = b.AccountId AND a.CompanyID = b.CompanyId;

DECLARE scursor CURSOR FOR  

SELECT id, name 
FROM [GetResultSheetChildren](@class, @companyid, 1)

Open scursor 

FETCH NEXT FROM scursor
INTO @accountId, @accountName

WHILE @@FETCH_STATUS = 0   
BEGIN

INSERT INTO @Balance
            (ClassId, ClassName, SubClassId, SubClassName,TDebit,TCredit,SDebit,SCredit,Balance, Currency, CompanyId, IsBalance)
SELECT        ClassId, ClassName, SubClassId, SubClassName, SUM(TDebit) AS TDebit, SUM(TCredit) AS TCredit, SUM(SDebit) AS SDebit, 
				SUM(SCredit) AS SCredit, SUM(Balance) AS Balance, Currency, CompanyId, 1 
FROM            @Balance
WHERE        (AccountId IN
					(SELECT     id
							FROM      dbo.GetChildren(@accountId, @companyid)))
GROUP BY ClassId, CompanyId, ClassName, SubClassId, SubClassName, Currency, IsBalance
HAVING IsBalance=0;

UPDATE @Balance set AccountId=@accountId, AccountName=@accountName WHERE AccountId IS NULL;

UPDATE @Balance Set IsBalance=1 WHERE AccountId=@accountId;

FETCH NEXT FROM scursor

INTO @accountId, @accountName
END

CLOSE scursor   

DEALLOCATE scursor
END

UPDATE       @Balance
SET                IsDebit = a.IsDebit
FROM            Account a INNER JOIN
                         @Balance b ON a.id = b.AccountId AND a.CompanyID = b.CompanyId;

SELECT * FROM @Balance where CompanyId=@companyid AND IsBalance=1 ORDER BY ID
go

