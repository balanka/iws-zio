CREATE FUNCTION [dbo].[GetGeneralLedgerYear]
(
	@id int
)
RETURNS Char(4)
AS
BEGIN
DECLARE @result Char(4);
SELECT @result= CONVERT(Char,DATEPART(Year, [TransDate])) 
FROM GeneralLedger
WHERE id = @id;
	RETURN @result
END
go

