CREATE PROCEDURE [dbo].[GetFiscalYears]
	@companyid NVARCHAR(6)
AS
	SET NOCOUNT ON

DECLARE @tmpCurrent  Table
(  
	CompanyId	NVARCHAR(50),
    CStart	NCHAR(6),
	CEnd	NCHAR(6)
)
INSERT INTO @tmpCurrent
SELECT        CompanyId, MIN(Period) AS CStart, MAX(Period) AS CEnd
FROM            FiscalYear
WHERE        (CompanyId = @companyid) AND ([Current] = 1) AND ([Open] = 1)
GROUP BY CompanyId

DECLARE @tmpOpened  Table
(  
	CompanyId	NVARCHAR(50),
    OStart	NCHAR(6),
	OEnd	NCHAR(6)
)
INSERT INTO @tmpOpened
SELECT        CompanyId, MIN(Period) AS OStart, MAX(Period) AS OEnd
FROM            FiscalYear
WHERE        (CompanyId = @companyid) AND ([Current] = 0) AND ([Open] = 1)
GROUP BY CompanyId
select a.CompanyId, CStart, CEnd, OStart, OEnd from @tmpCurrent a full outer join @tmpOpened b 
ON a.CompanyId=b.CompanyId
--where a.CompanyId=@companyid
go

