

CREATE FUNCTION [dbo].[GetSalesOrderNet]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=oTotal-oVat
FROM            SalesOrder 
WHERE id = @id;
	RETURN @result
END
go

