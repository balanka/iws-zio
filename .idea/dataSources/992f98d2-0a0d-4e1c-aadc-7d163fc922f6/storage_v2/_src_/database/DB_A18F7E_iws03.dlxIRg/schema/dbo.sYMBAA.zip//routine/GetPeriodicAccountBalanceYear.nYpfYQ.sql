CREATE FUNCTION [dbo].[GetPeriodicAccountBalanceYear]
(
	@id int
)
RETURNS Char(4)
AS
BEGIN
DECLARE @result Char(4);
SELECT @result=  SUBSTRING(rtrim(periode),1,4) 
FROM PeriodicAccountBalance
WHERE id = @id;
	RETURN @result
END
go

