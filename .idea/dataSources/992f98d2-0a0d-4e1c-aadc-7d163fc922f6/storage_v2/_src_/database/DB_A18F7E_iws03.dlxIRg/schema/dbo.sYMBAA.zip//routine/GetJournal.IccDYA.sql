
CREATE PROCEDURE [dbo].[GetJournal]
	@start NVARCHAR(6), 
	@end NVARCHAR(6), 
	@uiculture NVARCHAR(5), 
	@Companyid NVARCHAR(6)
	
AS
BEGIN

	SET NOCOUNT ON;

UPDATE       Journal
SET                CustSupplierName = Account.name
FROM            Journal INNER JOIN
                         Account ON Journal.CustSupplierID = Account.id
WHERE        (Journal.CustSupplierName IS NULL) AND (Journal.CompanyID=@companyId);

UPDATE       Journal
SET                TypeJournalName = TypeJournal.Name
FROM            Journal INNER JOIN
                         TypeJournal ON Journal.TypeJournal = TypeJournal.id
WHERE        (Journal.TypeJournalName IS NULL) AND (Journal.CompanyID=@companyId);

UPDATE       Journal
SET                StoreName = Store.name
FROM            Journal INNER JOIN
                         Store ON Journal.StoreID = Store.id
WHERE        (Journal.StoreName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                AccountName = Account.name
FROM            Journal INNER JOIN
                         Account ON Journal.Account = Account.id
WHERE        (Journal.AccountName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                OAccountName = Account.name
FROM            Journal INNER JOIN
                         Account ON Journal.OAccount = Account.id
WHERE        (Journal.OAccountName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                CustSupplierName = Customer.name
FROM            Journal INNER JOIN
                         Customer ON Journal.CustSupplierID = Customer.id
WHERE        (Journal.CustSupplierName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                CustSupplierName = Supplier.name
FROM            Journal INNER JOIN
                         Supplier ON Journal.CustSupplierID = Supplier.id
WHERE        (Journal.CustSupplierName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                CustSupplierName = Company.name
FROM            Journal INNER JOIN
                         Company ON Journal.CustSupplierID = Company.id
WHERE        (Journal.CustSupplierName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                CompanyName = Company.name
FROM            Journal INNER JOIN
                         Company ON Journal.CompanyID = Company.id
WHERE        (Journal.CompanyName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                CostCenterName = CostCenter.name
FROM            Journal INNER JOIN
                         CostCenter ON Journal.CostCenterId = CostCenter.id
WHERE        (Journal.CostCenterName IS NULL) AND (Journal.CompanyID=@companyId);

SELECT        Journal.ID, Journal.ItemID, Journal.OID, Localization.LocalName, Journal.CustSupplierID, Journal.TransDate, Journal.ItemDate, Journal.EntryDate, Journal.Periode, Journal.OYear, 
			Journal.oMonth, Journal.Account, Journal.AccountName, Journal.OAccount, Journal.OAccountName, Journal.Amount, Journal.CreditAvantImputationAmount,
			Journal.DebitAvantImputationAmount,Journal.DebitApresImputationAmount,Journal.CreditApresImputationAmount, Journal.Side, Journal.Currency, 
                    Journal.CompanyID, Journal.CustSupplierName AS Owner, Journal.TypeJournal, Journal.TypeJournalName, Journal.Info, Journal.CompanyIBAN, Journal.IBAN, Journal.ModelId, Journal.StoreName, Journal.CostCenterName
FROM            Journal INNER JOIN
                    Localization ON Journal.ItemType = Localization.ItemName
WHERE        (Journal.Periode BETWEEN @start AND @end) AND (Localization.UICulture = @uiculture) AND (Journal.CompanyID=@companyid)

END
go

