
CREATE PROCEDURE [dbo].[ClassChild]
@classId NVARCHAR(50),
@company NVARCHAR(50)

AS 
	SET NOCOUNT ON;
	SELECT ChildId,ChildName,ParentId,ParentName FROM dbo.GetChild(@classid, @company)
go

