CREATE FUNCTION [dbo].[GetPaymentYear]
(
	@id int
)
RETURNS Char(4)
AS
BEGIN
DECLARE @result Char(4);
SELECT @result= CONVERT(Char,DATEPART(Year, [TransDate])) 
FROM Payment
WHERE id = @id;
	RETURN @result
END
go

