

CREATE FUNCTION [dbo].[GetMasterLogisticTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineNet + lineVAT)
FROM            DetailLogistic 
WHERE transid = @id;
	RETURN @result
END
go

