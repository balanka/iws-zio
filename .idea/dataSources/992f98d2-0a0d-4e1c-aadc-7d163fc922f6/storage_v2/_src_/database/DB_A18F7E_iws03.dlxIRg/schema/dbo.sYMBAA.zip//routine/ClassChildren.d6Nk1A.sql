
CREATE PROCEDURE [dbo].[ClassChildren]
@classId NVARCHAR(50),
@company NVARCHAR(50)

AS 
	SET NOCOUNT ON;

WITH children AS
(
    SELECT id, name
        FROM Account WHERE id = @classId AND CompanyID=@company
    UNION ALL
    SELECT Account.id, Account.name 
	FROM Account  JOIN children  ON Account.ParentId = children.Id
)
SELECT id,name
    FROM children
go

