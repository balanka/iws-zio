CREATE FUNCTION [dbo].[GetPurchaseOrderYear]
(
	@id int
)
RETURNS Char(4)
AS
BEGIN
DECLARE @result Char(4);
SELECT @result= CONVERT(Char,DATEPART(Year, [TransDate])) 
FROM PurchaseOrder
WHERE id = @id;
	RETURN @result
END
go

