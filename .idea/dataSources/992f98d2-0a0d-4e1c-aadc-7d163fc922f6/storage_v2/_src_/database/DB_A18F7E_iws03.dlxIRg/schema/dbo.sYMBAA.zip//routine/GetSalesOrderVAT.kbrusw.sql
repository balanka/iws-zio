

CREATE FUNCTION [dbo].[GetSalesOrderVAT]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineVAT)
FROM            LineSalesOrder
WHERE transid = @id;
	RETURN @result
END
go

