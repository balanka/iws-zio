

CREATE PROCEDURE [dbo].[ClassAccountBalances]
@start	NVARCHAR(6), 
@end	NVARCHAR(6),
@companyid NVARCHAR(6)

AS 
	SET NOCOUNT ON;

--DELETE from @Balance 
DECLARE @Balance Table
(
    [ID]           INT            IDENTITY (1, 1) NOT NULL,
    [ClassId]      NVARCHAR (50)  NULL,
    [ClassName]    NVARCHAR (150) NULL,
    [SubClassId]   NVARCHAR (50)  NULL,
    [SubClassName] NVARCHAR (150) NULL,
    [AccountId]    NVARCHAR (50)  NULL,
    [AccountName]  NVARCHAR (150) NULL,
    [TDebit]       MONEY          NULL,
    [TCredit]      MONEY          NULL,
    [SDebit]       MONEY          NULL,
    [SCredit]      MONEY          NULL,
    [Currency]     NVARCHAR (50)  NULL,
    [Balance]      MONEY          DEFAULT ((0)) NULL,
    [CompanyId]    NVARCHAR (50)  NOT NULL,
    [IsBalance]    BIT            NULL
) 
  
DECLARE @class	NVARCHAR(12)
DECLARE db_cursor CURSOR FOR  
SELECT ClassID
FROM ClassSetup 
WHERE CompanyID = @companyid

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @class   

WHILE @@FETCH_STATUS = 0   
BEGIN

--INSERT @Balance (ID, AccountId, Name, TDebit, TCredit, SDebit, SCredit, Currency)  
--SELECT ID, AccountId, Name, TDebit, TCredit, SDebit, SCredit, Currency
--FROM dbo.GetAccountBalances(@class, @start, @end, @companyid)

FETCH NEXT FROM db_cursor INTO @class   
END   

CLOSE db_cursor   

DEALLOCATE db_cursor

SELECT * FROM @Balance ORDER BY ID
go

