-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetBrouillard]
	@TypeDoc VARCHAR(2),
	@NumPiece VARCHAR(15),
	@CompanyId VARCHAR(15),
	@ItemId INT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @tmpBrouillardCurrent  Table
(  
    [Id]          INT            NOT NULL PRIMARY KEY,
    [Period]      DATETIME       NOT NULL,
    [NumPiece]    NVARCHAR (20)  NULL,
    [AccountID]   NVARCHAR (20)  NOT NULL,
    [OAccountID]  NVARCHAR (20)  NOT NULL,
    [Owner]       NVARCHAR (50)  NULL,
    [HeaderText]  NVARCHAR (356) NULL,
    [Debit]       MONEY          NULL,
    [Credit]      MONEY          NULL,
    [Currency]    NVARCHAR (50)  NOT NULL,
    [TypeDoc]     NVARCHAR (50)  NOT NULL,
    [CompanyId]   NVARCHAR (50)  NOT NULL,
    [IsValidated] BIT            NULL
)
	DECLARE @tmpBrouillardDebit  Table
(  
    [Id]          INT            NOT NULL PRIMARY KEY,
    [Period]      DATETIME       NOT NULL,
    [NumPiece]    NVARCHAR (20)  NULL,
    [AccountID]   NVARCHAR (50)  NOT NULL,
    [OAccountID]  NVARCHAR (50)  NOT NULL,
    [Owner]       NVARCHAR (50)  NULL,
    [HeaderText]  NVARCHAR (356) NULL,
    [Debit]       MONEY          NULL,
    [Credit]      MONEY          NULL,
    [Currency]    NVARCHAR (50)  NOT NULL,
    [TypeDoc]     NVARCHAR (50)  NOT NULL,
    [CompanyId]   NVARCHAR (50)  NOT NULL,
    [IsValidated] BIT            NULL
)
	DECLARE @tmpBrouillardCredit  Table
(  
    [Id]          INT            NOT NULL PRIMARY KEY,
    [Period]      DATETIME       NOT NULL,
    [NumPiece]    NVARCHAR (20)  NULL,
    [AccountID]   NVARCHAR (50)  NOT NULL,
    [OAccountID]  NVARCHAR (50)  NOT NULL,
    [Owner]       NVARCHAR (50)  NULL,
    [HeaderText]  NVARCHAR (356) NULL,
    [Debit]       MONEY          NULL,
    [Credit]      MONEY          NULL,
    [Currency]    NVARCHAR (50)  NOT NULL,
    [TypeDoc]     NVARCHAR (50)  NOT NULL,
    [CompanyId]   NVARCHAR (50)  NOT NULL,
    [IsValidated] BIT            NULL
)
	DECLARE @tmpBrouillard  Table
(  
    [Id]          INT            NOT NULL PRIMARY KEY,
    [Period]      DATETIME       NOT NULL,
    [NumPiece]    NVARCHAR (10)  NULL,
    [AccountID]   NVARCHAR (50)  NOT NULL,
	[Side]		  BIT            NULL,
    [OAccountID]  NVARCHAR (50)  NOT NULL,
    [Owner]       NVARCHAR (10)  NULL,
    [HeaderText]        NVARCHAR (306) NOT NULL,
    [Amount]      MONEY          NULL,
    [Currency]    NVARCHAR (50)  NOT NULL,
    [TypeDoc]     NVARCHAR (50)  NOT NULL,
    [CompanyId]   NVARCHAR (50)  NOT NULL,
    [IsValidated] BIT            NULL
)
	UPDATE brouillard SET Debit=ISNULL(debit,0), Credit=ISNULL(credit,0)
			IF( @TypeDoc='OB')
	BEGIN
		INSERT INTO @tmpBrouillard
	SELECT Id, CAST(Concat('20',SUBSTRING(Date,5,2),SUBSTRING(Date,3,2),SUBSTRING(Date,1,2)) AS datetime) AS Period, NumPiece,
	IIF(Credit='0', AccountID, OAccountID) AS AccountID, 1 As Side, 
	IIF(Debit='0', AccountID, OAccountID) AS OAccountID, 
	IIF(LEN(ISNULL(Owner,''))=0,'G',Owner) As Owner, CONCAT(OAccountID, ' ', Text) AS HeaderText,
	IIF(Credit='0',	Debit, Credit) AS Amount,
	Currency,TypeDoc, CompanyId, IsValidated
	FROM Brouillard 
	WHERE TypeDoc=@TypeDoc AND NumPiece=@NumPiece AND CompanyId=@CompanyId AND IsValidated=0
	END
		IF(@TypeDoc='CS' )
	BEGIN
		INSERT INTO @tmpBrouillard
	SELECT Id, CAST(Concat('20',SUBSTRING(Date,5,2),SUBSTRING(Date,3,2),SUBSTRING(Date,1,2)) AS datetime) AS Period, NumPiece,
	IIF(Credit='0', AccountID, OAccountID) AS AccountID, 1 As Side, 
	IIF(Debit='0', AccountID, OAccountID) AS OAccountID, 
	IIF(LEN(ISNULL(Owner,''))=0,'G',Owner) As Owner, CONCAT(OAccountID, ' ', Text) AS HeaderText,
	IIF(Credit='0',	Debit, Credit) AS Amount,
	Currency,TypeDoc, CompanyId, IsValidated
	FROM Brouillard 
	WHERE TypeDoc=@TypeDoc AND NumPiece=@NumPiece AND CompanyId=@CompanyId AND Id=@ItemId  AND IsValidated=0
	END

	IF (@TypeDoc<>'CS')
	BEGIN

		INSERT INTO @tmpBrouillardCurrent
	SELECT         [Id], CAST(Concat('20',SUBSTRING(Date,5,2),SUBSTRING(Date,3,2),SUBSTRING(Date,1,2)) AS datetime) As Period, NumPiece,
	AccountID, OAccountID, Owner,CONCAT(OAccountID, ' ', Text) As Text, Convert(money,Debit,0) As Debit, Convert(money,Credit,0) As credit,
	Currency, TypeDoc, CompanyId, IsValidated
	FROM            Brouillard
	WHERE        (TypeDoc = @TypeDoc) AND (NumPiece = @NumPiece) AND (CompanyId = @CompanyId) AND (IsValidated=0)
		INSERT INTO @tmpBrouillardDebit
	SELECT         Id, Period, NumPiece, AccountID, OAccountID, Owner, HeaderText, Debit, Credit, Currency, TypeDoc, CompanyId, IsValidated
	FROM            @tmpBrouillardCurrent
	WHERE        (Credit = '0')
		INSERT INTO @tmpBrouillardCredit
	SELECT         Id, Period, NumPiece, AccountID, OAccountID, Owner, HeaderText, Debit, Credit, Currency, TypeDoc, CompanyId, IsValidated
	FROM            @tmpBrouillardCurrent
	WHERE        (Debit = '0')

	END
	IF(@TypeDoc='AI')
	BEGIN
		INSERT INTO @tmpBrouillard						
	select B.Id, B.Period, B.NumPiece, A.AccountID, 1 As Side, B.AccountID as OAccountID, ISNULL(B.Owner,A.Owner) AS Owner,
	CONCAT(B.OAccountID, ' ', B.HeaderText) AS HeaderText, IIF(B.Debit=0, B.Credit,B.Debit) As Amount,
	B.Currency, B.TypeDoc, B.CompanyId, B.IsValidated
	from @tmpBrouillardDebit A, @tmpBrouillardCredit B
	END
	IF(@TypeDoc='BQ' OR @TypeDoc='BK' OR @TypeDoc='AC' OR @TypeDoc='IM')-- OR @TypeDoc='AI')
	BEGIN
	UPDATE @tmpBrouillardDebit SET Owner=(SELECT Owner FROM @tmpBrouillardCredit WHERE Owner<>'' ) WHERE Owner=''
		INSERT INTO @tmpBrouillard						
	select B.Id, B.Period, B.NumPiece, A.AccountID, 1 As Side, B.AccountID as OAccountID, ISNULL(A.Owner,B.Owner) AS Owner,
	CONCAT(B.OAccountID, ' ', B.HeaderText) AS HeaderText, IIF(B.Debit=0, B.Credit,B.Debit) As Amount,
	B.Currency, B.TypeDoc, B.CompanyId, B.IsValidated
	from @tmpBrouillardDebit A, @tmpBrouillardCredit B
	END
	IF (@TypeDoc='VT' OR @TypeDoc='VP')
	BEGIN
		INSERT INTO @tmpBrouillard
	select A.Id, B.Period, B.NumPiece,  A.AccountID, 1 As Side, B.AccountID as OAccountID, ISNULL(A.Owner,B.Owner) AS Owner,
	CONCAT(B.OAccountID, ' ', B.HeaderText) AS HeaderText, IIF(A.Debit=0, A.Credit,A.Debit) As Amount,
	B.Currency, B.TypeDoc, B.CompanyId, B.IsValidated
	from @tmpBrouillardDebit A, @tmpBrouillardCredit B
	--select B.Id, B.Period, B.NumPiece,  A.AccountID, 1 As Side, B.AccountID as OAccountID, ISNULL(A.Owner,B.Owner) AS Owner,
	--CONCAT(B.OAccountID, ' ', B.HeaderText) AS HeaderText, IIF(B.Debit=0, B.Credit,B.Debit) As Amount,
	END

	SELECT     Id, Period, NumPiece, AccountID, Side, OAccountID, ISNULL(Owner,'G') AS Owner, HeaderText, Amount, Currency, TypeDoc, CompanyId, IsValidated
	FROM @tmpBrouillard

END
go

