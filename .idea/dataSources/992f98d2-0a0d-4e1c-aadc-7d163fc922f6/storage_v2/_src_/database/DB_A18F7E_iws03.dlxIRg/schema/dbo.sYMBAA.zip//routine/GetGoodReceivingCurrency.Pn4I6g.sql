CREATE FUNCTION [dbo].[GetGoodReceivingCurrency]
(
	@id int
)

RETURNS CHAR(10)
AS
BEGIN
DECLARE @result CHAR(10);
SELECT TOP 1 @result = Currency FROM LineGoodReceiving
WHERE transid = @id;
	RETURN @result
END
go

