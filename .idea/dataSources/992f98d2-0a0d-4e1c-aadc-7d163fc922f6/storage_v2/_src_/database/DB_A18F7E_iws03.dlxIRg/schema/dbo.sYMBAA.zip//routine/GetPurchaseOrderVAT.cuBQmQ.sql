


CREATE FUNCTION [dbo].[GetPurchaseOrderVAT]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineVAT)
FROM            LinePurchaseOrder
WHERE transid = @id;
	RETURN @result
END
go

