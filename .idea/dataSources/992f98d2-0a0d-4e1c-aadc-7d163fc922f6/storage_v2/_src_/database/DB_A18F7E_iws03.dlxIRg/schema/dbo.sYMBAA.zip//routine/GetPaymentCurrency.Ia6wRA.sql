
CREATE FUNCTION [dbo].[GetPaymentCurrency]
(
	@id int
)

RETURNS NVARCHAR(10)
AS
BEGIN
DECLARE @result NVARCHAR(10);
SELECT TOP 1 @result = Currency FROM LinePayment
WHERE transid = @id;
	RETURN @result
END
go

