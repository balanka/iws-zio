

CREATE FUNCTION [dbo].[GetResultBalanceSheetChildren](@classId NVARCHAR(50), 
@companyid NVARCHAR(50), @IsResultAccount BIT)  

RETURNS TABLE  
AS  
RETURN  

WITH children AS
(
    SELECT id, name, IIF(IsResultAccount =1, IsResultAccount, IsBalanceSheetAccount) AS isAccount
        FROM Account WHERE ParentId = @classId AND CompanyID=@companyid
    UNION ALL
    SELECT Account.id, Account.name, IIF(IsResultAccount =1, Account.IsResultAccount, Account.IsBalanceSheetAccount) 
	FROM Account  JOIN children  ON Account.ParentId = children.Id
)
SELECT id, name
    FROM children
	WHERE isAccount = @IsResultAccount
go

