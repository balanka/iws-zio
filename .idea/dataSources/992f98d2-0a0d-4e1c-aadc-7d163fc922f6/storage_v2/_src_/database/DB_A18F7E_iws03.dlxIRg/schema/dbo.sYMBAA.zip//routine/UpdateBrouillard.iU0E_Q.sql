-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateBrouillard]
	-- Add the parameters for the stored procedure here
	@TypeDoc VARCHAR(2),
	@CompanyId VARCHAR(15)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DELETE FROM tmpBrouillard
	INSERT INTO tmpBrouillard
							 (Id, Date, NumPiece, AccountID, OAccountID, Owner, Text, Debit, Credit, Currency, TypeDoc, CompanyId, IsValidated)
	SELECT        Id, Date, NumPiece, AccountID, OAccountID, Owner, Text, SUBSTRING(Debit,0,LEN(Debit)) AS Debit, SUBSTRING(Credit,0,LEN(Credit)) AS Credit, Currency, TypeDoc, CompanyId, IsValidated
	FROM Brouillard where NumPiece in (SELECT NumPiece
	FROM Brouillard
	WHERE (TypeDoc = @TypeDoc)
	GROUP BY NumPiece
	HAVING        (COUNT(NumPiece) = 2)) AND TypeDoc = @TypeDoc AND CompanyId=@CompanyId
	update tmpBrouillard set Debit=ISNULL(debit,0), credit=ISNULL(credit,0)

END
go

