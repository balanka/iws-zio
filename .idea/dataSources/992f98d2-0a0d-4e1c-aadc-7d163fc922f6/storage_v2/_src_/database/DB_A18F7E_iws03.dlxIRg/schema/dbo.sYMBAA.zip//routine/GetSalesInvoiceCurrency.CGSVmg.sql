
CREATE FUNCTION [dbo].[GetSalesInvoiceCurrency]
(
	@id int
)

RETURNS NVARCHAR(10)
AS
BEGIN
DECLARE @result NVARCHAR(10);
SELECT TOP 1 @result = Currency FROM LineSalesInvoice
WHERE transid = @id;
	RETURN @result
END
go

