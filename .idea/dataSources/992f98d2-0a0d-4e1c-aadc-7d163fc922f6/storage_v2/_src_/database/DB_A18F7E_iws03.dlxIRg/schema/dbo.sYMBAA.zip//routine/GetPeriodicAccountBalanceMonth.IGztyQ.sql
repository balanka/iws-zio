CREATE FUNCTION [dbo].[GetPeriodicAccountBalanceMonth]
(
	@id int
)
RETURNS char(2)
AS
BEGIN
DECLARE @result Char(2);
SELECT @result=  SUBSTRING(rtrim(periode),5,2)
FROM PeriodicAccountBalance
WHERE id = @id;
	RETURN @result
END
go

