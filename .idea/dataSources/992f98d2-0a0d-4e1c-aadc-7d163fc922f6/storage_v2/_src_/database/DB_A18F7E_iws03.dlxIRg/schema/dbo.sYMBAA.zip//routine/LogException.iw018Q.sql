CREATE Procedure [dbo].[LogException]  
(  
@Message nvarchar(256)='NA',  
@Type nvarchar(256)='NA', 
@Source nvarchar(256)='NA',  
@URL nvarchar(256)='NA',
@Target nvarchar(256)='NA',
@ComapnyId nvarchar(6),
@UserName nvarchar(6)
)  
as  
begin  
Insert into [LogExceptions]  
(  
EMessage, EType, ESource, ETarget, EURL,  LogDate, CompanyId, UserName
)  
select  
@Message, @Type,  @Source,  @Target, @URL, GETDATE(), @ComapnyId, @UserName;
return @@rowcount;
End
go

