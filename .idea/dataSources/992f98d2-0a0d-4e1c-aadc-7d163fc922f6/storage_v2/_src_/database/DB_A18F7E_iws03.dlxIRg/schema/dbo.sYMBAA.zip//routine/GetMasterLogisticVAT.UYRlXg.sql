
CREATE FUNCTION [dbo].[GetMasterLogisticVAT]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineVAT)
FROM            DetailLogistic 
WHERE transid = @id;
	RETURN @result
END

go

