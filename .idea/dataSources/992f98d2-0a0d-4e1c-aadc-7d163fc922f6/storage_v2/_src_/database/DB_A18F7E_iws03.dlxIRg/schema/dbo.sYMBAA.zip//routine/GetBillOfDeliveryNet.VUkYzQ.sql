

CREATE FUNCTION [dbo].[GetBillOfDeliveryNet]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=oTotal-oVat
FROM            BillOfDelivery 
WHERE id = @id;
	RETURN @result
END
go

