
CREATE FUNCTION [dbo].[GetBillOfDeliveryPeriode]
(
	@id int
)

RETURNS NVarchar(6)
AS
BEGIN
DECLARE @result NVarChar(6);
SELECT @result= CONVERT(NVarChar,DATEPART(Year, [TransDate])) + (CASE 
                WHEN (CONVERT(Int,LEN(CONVERT(NVarChar,DATEPART(Month, [TransDate]))))) = 1  
				THEN N'0' + (CONVERT(NVarChar,DATEPART(Month, [TransDate])))
                ELSE CONVERT(NVarChar,DATEPART(Month, [TransDate]))
             END)
FROM BillOfDelivery
WHERE id = @id;
	RETURN @result
END
go

