CREATE FUNCTION [dbo].[GetGoodReceivingYear]
(
	@id int
)
RETURNS Char(4)
AS
BEGIN
DECLARE @result Char(4);
SELECT @result= CONVERT(Char,DATEPART(Year, [TransDate])) 
FROM GoodReceiving
WHERE id = @id;
	RETURN @result
END
go

