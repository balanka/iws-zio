


CREATE FUNCTION [dbo].[GetJournal](@start NVARCHAR(6), @end NVARCHAR(6), @uiculture NVARCHAR(5), @companyid NVARCHAR(6))  
RETURNS TABLE  
AS  
RETURN  

SELECT        Journal.ID, Journal.ItemID, Journal.OID, Localization.LocalName, Journal.CustSupplierID, Journal.TransDate, Journal.Periode, Journal.OYear, Journal.oMonth, Journal.Account, Journal.OAccount, Journal.Amount, Journal.Side, Journal.Currency, 
                         Journal.CompanyID
FROM            Journal INNER JOIN
                         Localization ON Journal.ItemType = Localization.ItemName
WHERE        (Journal.Periode BETWEEN @start AND @end) AND (Localization.UICulture = @uiculture)
go

