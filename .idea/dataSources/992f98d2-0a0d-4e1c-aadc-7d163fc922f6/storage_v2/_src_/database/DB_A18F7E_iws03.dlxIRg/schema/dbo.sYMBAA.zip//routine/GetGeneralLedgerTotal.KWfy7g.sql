
CREATE FUNCTION [dbo].[GetGeneralLedgerTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM([amount]) FROM LineGeneralLedger
WHERE transid = @id;
	RETURN @result
END
go

