-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SetTypeJournal]

	@typeDoc varchar(100),
	@transid int,
	@companyid nvarchar(50)
AS
BEGIN

	SET NOCOUNT ON;

	declare @type varchar(50);
	
			IF(LOWER(@typeDoc)='payment' )
	BEGIN
	
	SELECT @type = TypeJournalID FROM AffectationJournal WHERE AccountID IN(
	SELECT id FROM  GetParents((SELECT TOP 1 account FROM LinePayment WHERE transid=@transid), @companyid)) AND  OAccountID IN(
	SELECT id FROM GetParents((SELECT TOP 1 oaccount FROM LinePayment WHERE transid=@transid), @companyid)) AND 
	Side=(SELECT TOP 1 side FROM LinePayment WHERE transid=@transid);
	UPDATE Payment set TypeJournal=@type WHERE id=@transid;
	END
			IF(Lower(@typeDoc)='settlement' )
	BEGIN
	
	SELECT @type = TypeJournalID FROM AffectationJournal WHERE AccountID IN(
	SELECT id FROM  GetParents((SELECT TOP 1 account FROM LineSettlement WHERE transid=@transid), @companyid)) AND  OAccountID IN(
	SELECT id FROM GetParents((SELECT TOP 1 oaccount FROM LineSettlement WHERE transid=@transid), @companyid)) AND 
	Side=(SELECT TOP 1 side FROM LineSettlement WHERE transid=@transid)
	UPDATE Settlement set TypeJournal=@type WHERE id=@transid;
	END
			IF(Lower(@typeDoc)='vendorinvoice' )
	BEGIN
	
	SELECT @type = TypeJournalID FROM AffectationJournal WHERE AccountID IN(
	SELECT id FROM  GetParents((SELECT TOP 1 account FROM LineVendorInvoice WHERE transid=@transid), @companyid)) AND  OAccountID IN(
	SELECT id FROM GetParents((SELECT TOP 1 oaccount FROM LineVendorInvoice WHERE transid=@transid), @companyid)) AND 
	Side=(SELECT TOP 1 side FROM LineVendorInvoice WHERE transid=@transid);
	UPDATE VendorInvoice set TypeJournal=@type WHERE id=@transid;
	END
			IF(Lower(@typeDoc)='customerinvoice' )
	BEGIN
	
	SELECT @type = TypeJournalID FROM AffectationJournal WHERE AccountID IN(
	SELECT id FROM  GetParents((SELECT TOP 1 account FROM LineCustomerInvoice WHERE transid=@transid), @companyid)) AND  OAccountID IN(
	SELECT id FROM GetParents((SELECT TOP 1 oaccount FROM LineCustomerInvoice WHERE transid=@transid), @companyid)) AND 
	Side=(SELECT TOP 1 side FROM LineCustomerInvoice WHERE transid=@transid);
	UPDATE CustomerInvoice set TypeJournal=@type WHERE id=@transid;
	END
			IF(Lower(@typeDoc)='generalledger' )
	BEGIN
	
	SELECT @type = TypeJournalID FROM AffectationJournal WHERE AccountID IN(
	SELECT id FROM  GetParents((SELECT TOP 1 account FROM LineGeneralLedger WHERE transid=@transid), @companyid)) AND  OAccountID IN(
	SELECT id FROM GetParents((SELECT TOP 1 oaccount FROM LineGeneralLedger WHERE transid=@transid), @companyid)) AND 
	Side=(SELECT TOP 1 side FROM LineGeneralLedger WHERE transid=@transid);
	UPDATE GeneralLedger set TypeJournal=@type WHERE id=@transid;
	END

	RETURN @@ROWCOUNT

END
go

