CREATE FUNCTION [dbo].[GetAccountBalances](
@class	NVARCHAR(12),
@start	NVARCHAR(6), 

@companyid NVARCHAR(6))

RETURNS TABLE
AS
RETURN

SELECT    AccountId, Name, SUM(Debit) AS TDebit, SUM(Credit) AS TCredit, iif((SUM(Debit)-SUM(Credit))<0,0,SUM(Debit)-SUM(Credit)) AS SDebit,iif((SUM(Credit)-SUM(Debit))<0,0,SUM(Credit)-SUM(Debit)) AS SCredit, Currency
FROM            GetAccountBalance(@class, @start, @companyid)
GROUP BY AccountId, Name, Currency;
go

