
CREATE FUNCTION [dbo].[GetSalesOrderTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineNet)
FROM            LineSalesOrder 
WHERE transid = @id;
	RETURN @result
END
go

