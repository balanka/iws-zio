CREATE FUNCTION [dbo].[GetSettlementYear]
(
	@id int
)
RETURNS Char(4)
AS
BEGIN
DECLARE @result Char(4);
SELECT @result= CONVERT(Char,DATEPART(Year, [TransDate])) 
FROM Settlement
WHERE id = @id;
	RETURN @result
END
go

