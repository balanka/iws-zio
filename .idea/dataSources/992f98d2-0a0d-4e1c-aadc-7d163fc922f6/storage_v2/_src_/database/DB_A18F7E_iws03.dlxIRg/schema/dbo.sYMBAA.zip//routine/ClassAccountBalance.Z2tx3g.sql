


CREATE PROCEDURE [dbo].[ClassAccountBalance]
@class	NVARCHAR(12),
@start	NVARCHAR(6), 
@end	NVARCHAR(6),
@companyid NVARCHAR(6)

AS 
	SET NOCOUNT ON;
SELECT    LEFT(AccountId, 1) AS ID, AccountId, Name, SUM(Debit) AS TDebit, SUM(Credit) AS TCredit, iif((SUM(Debit)-SUM(Credit))<0,0,SUM(Debit)-SUM(Credit)) AS SDebit,iif((SUM(Credit)-SUM(Debit))<0,0,SUM(Credit)-SUM(Debit)) AS SCredit, Currency
FROM            GetAccountBalance(@class, @start, @end, @companyid)
GROUP BY AccountId, Name, Currency

ORDER BY ID;
go

