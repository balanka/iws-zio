
CREATE FUNCTION [dbo].[GetCustomerInvoiceTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM([amount]) FROM LineCustomerInvoice
WHERE transid = @id;
	RETURN @result
END
go

