
CREATE FUNCTION [dbo].[GetBillOfDeliveryTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineNet)
FROM            LineBillOfDelivery 
WHERE transid = @id;
	RETURN @result
END
go

