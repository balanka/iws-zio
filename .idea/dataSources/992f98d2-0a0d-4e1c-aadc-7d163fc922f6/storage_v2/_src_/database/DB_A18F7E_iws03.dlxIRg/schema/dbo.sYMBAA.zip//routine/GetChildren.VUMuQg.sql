CREATE FUNCTION [dbo].[GetChildren](@id NVARCHAR(50), 
@companyid NVARCHAR(50))  

RETURNS TABLE  
AS  
RETURN  

WITH children AS
(
    SELECT id
        FROM Account WHERE ParentId = @id AND CompanyID=@companyid
    UNION ALL
    SELECT Account.id
	FROM Account  JOIN children  ON Account.ParentId = children.Id
)
SELECT id
    FROM children
go

