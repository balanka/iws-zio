
--CREATE FUNCTION [dbo].[GetInventoryInvoiceVAT]
--(
--	@id int
--)

--RETURNS MONEY
--AS
--BEGIN
--DECLARE @result MONEY;
--SELECT @result=SUM(lineVAT)
--FROM            LineInventoryInvoice 
--WHERE transid = @id;
--	RETURN @result
--END




CREATE FUNCTION [dbo].[GetInventoryInvoiceTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineNet)
FROM            LineInventoryInvoice 
WHERE transid = @id;
	RETURN @result
END
go

