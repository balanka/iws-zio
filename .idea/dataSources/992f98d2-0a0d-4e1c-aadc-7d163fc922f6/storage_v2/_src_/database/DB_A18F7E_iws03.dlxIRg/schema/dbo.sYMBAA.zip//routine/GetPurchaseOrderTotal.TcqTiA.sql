CREATE FUNCTION [dbo].[GetPurchaseOrderTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineNet)
FROM            LinePurchaseOrder 
WHERE transid = @id;
	RETURN @result
END
go

