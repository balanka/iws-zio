

CREATE FUNCTION [dbo].[GetGoodReceivingTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM(lineNet)
FROM            LineGoodReceiving
WHERE transid = @id;
	RETURN @result
END
go

