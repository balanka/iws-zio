
CREATE FUNCTION [dbo].[GetVendorInvoiceTotal]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=SUM([amount]) FROM LineVendorInvoice
WHERE transid = @id;
	RETURN @result
END
go

