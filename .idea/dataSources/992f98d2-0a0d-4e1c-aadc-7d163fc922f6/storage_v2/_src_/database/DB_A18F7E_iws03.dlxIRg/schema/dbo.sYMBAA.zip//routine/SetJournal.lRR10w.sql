
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SetJournal]
	@transid int,
	@companyid nvarchar(50)
AS
BEGIN

	SET NOCOUNT ON;

	declare @type varchar(50);
	
	BEGIN
	
	SELECT @type = TypeJournalID FROM AffectationJournal WHERE AccountID IN(
	SELECT id FROM  GetParents((SELECT TOP 1 account FROM DetailCompta WHERE transid=@transid), @companyid)) AND  OAccountID IN(
	SELECT id FROM GetParents((SELECT TOP 1 oaccount FROM DetailCompta WHERE transid=@transid), @companyid)) AND 
	Side=(SELECT TOP 1 side FROM DetailCompta WHERE transid=@transid);
	UPDATE MasterCompta set TypeJournal=@type WHERE id=@transid;
	END

	RETURN @@ROWCOUNT

END
go

