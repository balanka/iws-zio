CREATE PROCEDURE [dbo].[CloseFiscalYear]
	@companyId NVARCHAR(6)
AS
	SET NOCOUNT ON;

DECLARE @Period VARCHAR(6),@NextPeriod VARCHAR(6), @NStart VARCHAR(6),@NEnd VARCHAR(6),@StringYear VARCHAR(4), @StringMonth VARCHAR(2);

DECLARE @StartDate DATE,@EndDate DATE,@IncrementDate DATE;

DECLARE @Counter INT = 0, @Increment INT = 0;

DECLARE @tmpFiscalYear  Table
(  
[Id]		INT		IDENTITY (1, 1) NOT NULL,
[AccountId]	NVARCHAR(50)	NOT NULL,
[Name]		NVARCHAR(150)	NOT NULL,
[Periode]	NVARCHAR(50)	NOT NULL,
[Debit]		Decimal(9,2)	Default 0,
[Credit]	Decimal(9,2)	Default 0,
[InitialBalance]	Decimal(9,2)	Default 0,
[FinalBalance]	Decimal(9,2)	Default 0,
[Currency]	NVARCHAR(10)	NOT NULL,
CompanyId	NVARCHAR(50)	NOT NULL,
PRIMARY KEY CLUSTERED ([AccountId] ASC, [Periode] ASC)
)
SET @NStart = (SELECT        MIN(Period)
	FROM            FiscalYear
	WHERE        (CompanyId = @companyid) AND ([Current] = 1) AND ([Open] = 1));
SET @NEnd = (SELECT        MAX(Period)
	FROM            FiscalYear
	WHERE        (CompanyId = @companyid) AND ([Current] = 1) AND ([Open] = 1));
SET @StartDate	= convert(Date, concat(substring(@NStart,1,4), '-', substring(@NStart,5,2), '-', '28'));
SET @EndDate	= convert(Date, concat(substring(@NEnd,1,4), '-', substring(@NEnd,5,2), '-', '28'));
SET @Counter	= 1+DATEDIFF(month, @Startdate, @EndDate);
		 
	WHILE (@Increment < @Counter)
	BEGIN

		SET @IncrementDate=DATEADD(month, @Increment, @StartDate);

		SET @StringYear=YEAR(@IncrementDate);

		SET @StringMonth=MONTH(@IncrementDate);

		IF LEN(@StringMonth) < 2
		BEGIN
		SET @StringMonth='0' + @StringMonth
		END

		SET @Period=concat(@StringYear,@StringMonth);

		SET @IncrementDate=DATEADD(month, @Increment + 1, @StartDate);

		SET @StringYear=YEAR(@IncrementDate);

		SET @StringMonth=MONTH(@IncrementDate);

		IF LEN(@StringMonth)<2
		BEGIN
		SET @StringMonth='0'+@StringMonth;
		END

		SET @NextPeriod=concat(@StringYear,@StringMonth);

			INSERT INTO PeriodicAccountBalance
			(AccountId, Name, Periode, Debit, Credit, InitialBalance, FinalBalance, Currency, CompanyID)
			SELECT AccountId,Name,@NextPeriod AS Periode,0 AS Debit,0 AS Credit,0 AS InitialBalance,0 AS FinalBalance,Currency,CompanyId
			FROM (
					SELECT DISTINCT AccountId,Name,Currency,CompanyId 
					FROM PeriodicAccountBalance 
					WHERE Periode <= @NextPeriod) A
			WHERE NOT EXISTS(
					SELECT AccountId, Periode 
					FROM PeriodicAccountBalance B 
					WHERE ( (B.Periode = @NextPeriod) AND (B.AccountId = A.AccountId)));

		SET @Increment=1+@Increment;
	END

BEGIN TRANSACTION
	BEGIN TRY	 
	WITH m AS (
	SELECT AccountId, Periode, Debit, IDebit, 
	  nx = SUM(Debit) OVER 
	  (
		PARTITION BY Accountid 
		ORDER BY Periode ROWS UNBOUNDED PRECEDING
	  )
	  FROM PeriodicAccountBalance
	)
	UPDATE m
		 SET IDebit = nx-Debit;
		 --WHERE @companyId=@companyId;

	WITH m AS (
	SELECT AccountId, Periode, Credit, ICredit, 
	  nx = SUM(Credit) OVER 
	  (
		PARTITION BY Accountid 
		ORDER BY Periode ROWS UNBOUNDED PRECEDING
	  )
	  FROM PeriodicAccountBalance
	)
	UPDATE m
		 SET ICredit = nx-Credit;
		  --WHERE @companyId=@companyId;

	IF @@TRANCOUNT > 0
		COMMIT;
	END TRY

	BEGIN CATCH 

	IF @@TRANCOUNT > 0
		ROLLBACK;
 	END CATCH
		 
SELECT AccountId, Name, Periode, Debit, Credit, InitialBalance, FinalBalance, Currency, CompanyID 
FROM  PeriodicAccountBalance 
WHERE CONVERT(int, Periode) >= CONVERT(int, @NStart) AND CONVERT(int, Periode) <= CONVERT(int, @NEnd) 
ORDER BY AccountId, Periode;
go

