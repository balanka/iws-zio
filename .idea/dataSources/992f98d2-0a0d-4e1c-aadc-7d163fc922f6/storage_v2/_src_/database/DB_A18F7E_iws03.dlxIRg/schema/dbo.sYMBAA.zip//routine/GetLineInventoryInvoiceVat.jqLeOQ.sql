CREATE FUNCTION [dbo].[GetLineInventoryInvoiceVat]
(
	@id int
)
RETURNS MONEY
AS
BEGIN
	DECLARE @result MONEY;
SELECT @result=ROUND((price * quantity * Vat),2)
FROM            LineInventoryInvoice 
WHERE id = @id;
	RETURN @result

END
go

