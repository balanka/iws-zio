
CREATE PROCEDURE [dbo].[PeriodicBalances]
@start NVARCHAR(6),
@end NVARCHAR(6),
@selectedIDs	NVARCHAR(550), 
@companyid NVARCHAR(4)

AS 
	SET NOCOUNT ON;

DECLARE @Periodic Table
(
    [Id]          INT            IDENTITY (1, 1) NOT NULL,
    [AccountId]   NVARCHAR (50)  NOT NULL,
    [AccountName] NVARCHAR (150) NULL,
    [Periode]     NVARCHAR (16)  NOT NULL,
    [OYear]       NVARCHAR (4)   NULL,
    [OMonth]      NVARCHAR (2)   NULL,
    [Debit]       MONEY          DEFAULT ((0)) NULL,
    [Credit]      MONEY          DEFAULT ((0)) NULL,
	[InitialBalance]     MONEY          DEFAULT ((0)) NULL,
	[FinalBalance]     MONEY          DEFAULT ((0)) NULL,
    [Balance]     MONEY          DEFAULT ((0)) NULL,
	[SDebit]       MONEY          DEFAULT ((0)) NULL,
    [SCredit]      MONEY          DEFAULT ((0)) NULL,
    [Currency]    NVARCHAR (50)  NULL,
    [IsBalance]   BIT            DEFAULT 0,
	[XCurrent]   BIT            DEFAULT 0,
	[XOpen]   BIT            DEFAULT 0,
    [CompanyId]   NVARCHAR (50)  NOT NULL,
	PRIMARY KEY CLUSTERED ([AccountId] ASC, [Periode] ASC)
);

--	INSERT INTO @Periodic
--		(AccountId, AccountName, Periode, OYear, OMonth, Debit, Credit, InitialBalance, FinalBalance, Currency, CompanyID)--, IsBalance, XCurrent, XOpen
--	SELECT  AccountId, Name AS AccountName, Periode, OYear, OMonth, SUM(Debit) AS Debit, SUM(Credit) AS Credit, 
--			SUM(InitialBalance) AS InitialBalance, SUM(FinalBalance) AS FinalBalance, Currency, CompanyID--0 AS IsBalance,0 AS XCurrent,0 AS XOpen, 
--	FROM            PeriodicAccountBalance
--	WHERE (CompanyID = @companyId) --AND (Periode IN
--								 --(SELECT        Period
--								   --FROM            FiscalYear
--								   --WHERE        ([Current] = 1) AND ([Open] = 1) AND (CompanyID = @companyId)))
--								   AND (convert(int,Periode) BETWEEN convert(int,@start) AND convert(int, @end))
--	GROUP BY AccountId, Name, Periode,oYear,oMonth, Currency, CompanyID--, XCurrent, XOpen
--	ORDER BY AccountId, Periode;

--UPDATE @Periodic SET p.[XCurrent] = f.[Current], p.[XOpen] = f.[Open]
--from FiscalYear f
--INNER JOIN @Periodic p
--ON p.periode = f.period
--where f.Companyid = @companyid and p.companyid = @companyid;


--		WITH m AS (
--	SELECT AccountId, Periode, Debit, Credit, InitialBalance, FinalBalance, XCurrent, XOpen,
--	  nx = SUM(Debit-Credit+InitialBalance) OVER 
--	  (
--		PARTITION BY Accountid 
--		ORDER BY Periode ROWS UNBOUNDED PRECEDING
--	  )
--	  FROM @Periodic
--	)
--	UPDATE m
--		 SET InitialBalance = IIF(XCurrent=0 And XOpen=0,InitialBalance, nx-Debit+Credit), FinalBalance = IIF(XCurrent=0 And XOpen=0,Finalbalance, nx);

--UPDATE @Periodic set SDebit=IIF(FinalBalance>=0,FinalBalance,0), SCredit=IIF(FinalBalance>=0,0,-FinalBalance);

--SELECT P.*
--FROM @Periodic P
----INNER JOIN (SELECT AccountId, MAX(Periode) AS latest
----           FROM PeriodicAccountBalance
----           GROUP BY AccountId) 
----ON L.AccountId = P.AccountId
----AND L.latest = P.Periode
--Order by AccountId,Periode

SELECT AccountId, Name, Periode, oyear, oMonth, Debit, Credit, IDebit, ICredit, (IDebit + Debit) As FDebit, (ICredit + Credit) As FCredit, Currency, CompanyID FROM  PeriodicAccountBalance
 WHERE (CompanyID = @companyid) AND (Convert(INT,Periode) BETWEEN Convert(INT,@start) AND Convert(INT,@end))
 ORDER BY AccountId, Periode;
go

