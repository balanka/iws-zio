


CREATE FUNCTION [dbo].[GetLineSalesOrderNet]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=ROUND((price * quantity), 2)
FROM            LineSalesOrder 
						 WHERE id= @id;
	RETURN @result
END
go

