CREATE FUNCTION [dbo].[GetChild](@classId NVARCHAR(50), @companyid NVARCHAR(50))  
RETURNS TABLE  
AS  
RETURN  
SELECT child.Id AS ChildId, child.name AS ChildName, parent.Id AS ParentId, parent.name AS ParentName
    FROM Account AS child
    LEFT JOIN Account AS parent ON child.ParentId = parent.Id
	WHERE parent.Id=@classId
go

