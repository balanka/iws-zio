CREATE PROCEDURE [dbo].[OpenFiscalYear]
@NStart VARCHAR(6),
@NEnd VARCHAR(6),
@CompanyId VARCHAR(50),
@Current BIT,
@Open BIT
AS
DECLARE @Period VARCHAR(6);

DECLARE @StartDate DATE = convert(Date, substring(@NStart,1,4) +'-'+ substring(@NStart,5,2) +'-' + '28');

DECLARE @EndDate DATE = convert(Date, substring(@NEnd,1,4) +'-'+ substring(@NEnd,5,2) +'-' + '28');

DECLARE @Counter INT = 1+DATEDIFF(month, @Startdate, @EndDate);

DECLARE @Increment INT = 0;

DECLARE @IncrementDate DATE;

DECLARE @StringYear VARCHAR(4);

DECLARE @StringMonth VARCHAR(2);
UPDATE FiscalYear SET [Current] = 0, [Open] = 0 WHERE [Current] = 1 AND [Open] = 1 
WHILE (@Increment < @Counter)
BEGIN

	SET @IncrementDate=DATEADD(month, @Increment, @StartDate);

	SET @StringYear=YEAR(@IncrementDate);

	SET @StringMonth=MONTH(@IncrementDate);

	IF LEN(@StringMonth)<2
	BEGIN
	SET @StringMonth='0'+@StringMonth
	END

	SET @Period=CONCAT(@StringYear,@StringMonth);

	MERGE FiscalYear AS target
	USING (SELECT @Period, @CompanyId) AS source ([Period], [CompanyId])
	ON target.[Period] = source.[Period] AND target.[CompanyId] = source.[CompanyId]
	WHEN MATCHED THEN
	   UPDATE SET target.[Current] = @Current, target.[Open]=@Open
	WHEN NOT MATCHED THEN
	   INSERT ([Period], [CompanyId], [Current], [Open]) VALUES (source.[Period], source.[CompanyId],@Current,@Open);
   
   	SET @IncrementDate=DATEADD(month, @Increment+@Counter, @StartDate);

	SET @StringYear=YEAR(@IncrementDate);

	SET @StringMonth=MONTH(@IncrementDate);

	IF LEN(@StringMonth)<2
	BEGIN
	SET @StringMonth='0'+@StringMonth;
	END

	SET @Period=CONCAT(@StringYear,@StringMonth);

	MERGE FiscalYear AS target
	USING (SELECT @Period, @CompanyId) AS source ([Period], [CompanyId])
	ON target.[Period] = source.[Period] AND target.[CompanyId] = source.[CompanyId]
	WHEN MATCHED THEN
	   UPDATE SET target.[Current] = 0, target.[Open]=1
	WHEN NOT MATCHED THEN
	   INSERT ([Period], [CompanyId], [Current], [Open]) VALUES (source.[Period], source.[CompanyId],0,1);

SET @Increment=@Increment+1;
END
go

