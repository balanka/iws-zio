

CREATE FUNCTION [dbo].[GetBillOfDeliveryVAT]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result = SUM(lineVAT)
FROM            LineBillOfDelivery
WHERE transid = @id;
	RETURN @result
END
go

