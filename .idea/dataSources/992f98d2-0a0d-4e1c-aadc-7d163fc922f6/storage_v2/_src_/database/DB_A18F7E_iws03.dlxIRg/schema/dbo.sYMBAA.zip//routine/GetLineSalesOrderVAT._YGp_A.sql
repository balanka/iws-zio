


CREATE FUNCTION [dbo].[GetLineSalesOrderVAT]
(
	@id int
)

RETURNS MONEY
AS
BEGIN
DECLARE @result MONEY;
SELECT @result=ROUND((price * quantity * Vat), 2)
FROM            LineSalesOrder 
						 WHERE id= @id;
	RETURN @result
END
go

