-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateJournal]
	
	@CompanyId VARCHAR(15)
AS
BEGIN

	SET NOCOUNT ON;

UPDATE       Journal
SET                StoreName = Store.name
FROM            Journal INNER JOIN
                         Store ON Journal.StoreID = Store.id
WHERE        (Journal.StoreName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                AccountName = Account.name
FROM            Journal INNER JOIN
                         Account ON Journal.Account = Account.id
WHERE        (Journal.AccountName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                OAccountName = Account.name
FROM            Journal INNER JOIN
                         Account ON Journal.OAccount = Account.id
WHERE        (Journal.OAccountName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                CustSupplierName = Customer.name
FROM            Journal INNER JOIN
                         Customer ON Journal.CustSupplierID = Customer.id
WHERE        (Journal.CustSupplierName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                CustSupplierName = Supplier.name
FROM            Journal INNER JOIN
                         Supplier ON Journal.CustSupplierID = Supplier.id
WHERE        (Journal.CustSupplierName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                CustSupplierName = Company.name
FROM            Journal INNER JOIN
                         Company ON Journal.CustSupplierID = Company.id
WHERE        (Journal.CustSupplierName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                CompanyName = Company.name
FROM            Journal INNER JOIN
                         Company ON Journal.CompanyID = Company.id
WHERE        (Journal.CompanyName IS NULL) AND (Journal.CompanyID=@companyId);
UPDATE       Journal
SET                TypeJournalName = TypeJournal.name
FROM            Journal INNER JOIN
                         TypeJournal ON Journal.TypeJournal = TypeJournal.id
WHERE        (Journal.TypeJournalName IS NULL) AND (Journal.CompanyID=@companyId);
END
go

