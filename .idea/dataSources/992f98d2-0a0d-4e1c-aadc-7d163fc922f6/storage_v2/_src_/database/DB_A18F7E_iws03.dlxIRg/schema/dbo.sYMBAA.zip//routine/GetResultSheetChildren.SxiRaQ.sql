
---IsResultAccount

CREATE FUNCTION [dbo].[GetResultSheetChildren](@classId NVARCHAR(50), 
@companyid NVARCHAR(50), @IsResultAccount BIT)  

RETURNS TABLE  
AS  
RETURN  

WITH children AS
(
    SELECT id, name, IsResultAccount
        FROM Account WHERE ParentId = @classId AND CompanyID=@companyid-- AND IsResultAccount=@IsResultAccount
    UNION ALL
    SELECT Account.id, Account.name, Account.IsResultAccount 
	FROM Account  JOIN children  ON Account.ParentId = children.Id
)
SELECT id, name
    FROM children
	WHERE IsResultAccount = @IsResultAccount

go

