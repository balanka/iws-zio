

CREATE PROCEDURE [dbo].[account1To7]
@start	NVARCHAR(6), 
@end	NVARCHAR(6),
@companyid NVARCHAR(6)

AS 
	SET NOCOUNT ON;
SELECT     1 AS gr,   LEFT(AccountId, 1) AS ID, AccountId, Name, SUM(Debit) AS TDebit, SUM(Credit) AS TCredit, iif((SUM(Debit)-SUM(Credit))<0,0,SUM(Debit)-SUM(Credit)) AS SDebit,iif((SUM(Credit)-SUM(Debit))<0,0,SUM(Credit)-SUM(Debit)) AS SCredit, Currency
FROM            GetAccountBalance('1', @start, @end, @companyid)
GROUP BY AccountId, Name, Currency

UNION
SELECT     1 AS gr,   LEFT(AccountId, 1) AS ID, AccountId, Name, SUM(Debit) AS TDebit, SUM(Credit) AS TCredit, iif((SUM(Debit)-SUM(Credit))<0,0,SUM(Debit)-SUM(Credit)) AS SDebit,iif((SUM(Credit)-SUM(Debit))<0,0,SUM(Credit)-SUM(Debit)) AS SCredit, Currency
FROM            GetAccountBalance('2', @start, @end, @companyid)
GROUP BY AccountId, Name, Currency

UNION
SELECT     1 AS gr,   LEFT(AccountId, 1) AS ID, AccountId, Name, SUM(Debit) AS TDebit, SUM(Credit) AS TCredit, iif((SUM(Debit)-SUM(Credit))<0,0,SUM(Debit)-SUM(Credit)) AS SDebit,iif((SUM(Credit)-SUM(Debit))<0,0,SUM(Credit)-SUM(Debit)) AS SCredit, Currency
FROM            GetAccountBalance('3', @start, @end, @companyid)
GROUP BY AccountId, Name, Currency

UNION
SELECT     1 AS gr,   LEFT(AccountId, 1) AS ID, AccountId, Name, SUM(Debit) AS TDebit, SUM(Credit) AS TCredit, iif((SUM(Debit)-SUM(Credit))<0,0,SUM(Debit)-SUM(Credit)) AS SDebit,iif((SUM(Credit)-SUM(Debit))<0,0,SUM(Credit)-SUM(Debit)) AS SCredit, Currency
FROM            GetAccountBalance('4', @start, @end, @companyid)
GROUP BY AccountId, Name, Currency

UNION
SELECT     1 AS gr,   LEFT(AccountId, 1) AS ID, AccountId, Name, SUM(Debit) AS TDebit, SUM(Credit) AS TCredit, iif((SUM(Debit)-SUM(Credit))<0,0,SUM(Debit)-SUM(Credit)) AS SDebit,iif((SUM(Credit)-SUM(Debit))<0,0,SUM(Credit)-SUM(Debit)) AS SCredit, Currency
FROM            GetAccountBalance('5', @start, @end, @companyid)
GROUP BY AccountId, Name, Currency

UNION
SELECT     2 AS gr,   LEFT(AccountId, 1) AS ID, AccountId, Name, SUM(Debit) AS TDebit, SUM(Credit) AS TCredit, iif((SUM(Debit)-SUM(Credit))<0,0,SUM(Debit)-SUM(Credit)) AS SDebit,iif((SUM(Credit)-SUM(Debit))<0,0,SUM(Credit)-SUM(Debit)) AS SCredit, Currency
FROM            GetAccountBalance('6', @start, @end, @companyid)
GROUP BY AccountId, Name, Currency

UNION
SELECT     2 AS gr,   LEFT(AccountId, 1) AS ID, AccountId, Name, SUM(Debit) AS TDebit, SUM(Credit) AS TCredit, iif((SUM(Debit)-SUM(Credit))<0,0,SUM(Debit)-SUM(Credit)) AS SDebit,iif((SUM(Credit)-SUM(Debit))<0,0,SUM(Credit)-SUM(Debit)) AS SCredit, Currency
FROM            GetAccountBalance('7', @start, @end, @companyid)
GROUP BY AccountId, Name, Currency

ORDER BY ID;

go

