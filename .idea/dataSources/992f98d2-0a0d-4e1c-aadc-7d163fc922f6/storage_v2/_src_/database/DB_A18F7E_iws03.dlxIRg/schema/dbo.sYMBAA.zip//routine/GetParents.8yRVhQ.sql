
CREATE FUNCTION [dbo].[GetParents](@id NVARCHAR(50), @companyid NVARCHAR(50))  
RETURNS TABLE  
AS  
RETURN  
WITH parents AS
(
    SELECT Account.*
        FROM Account WHERE id = @id AND CompanyID=@companyid
    UNION ALL
    SELECT Account.* FROM Account  JOIN parents  ON Account.Id = parents.ParentID
)
SELECT id, name
    FROM parents
	WHERE id <> @id
go

