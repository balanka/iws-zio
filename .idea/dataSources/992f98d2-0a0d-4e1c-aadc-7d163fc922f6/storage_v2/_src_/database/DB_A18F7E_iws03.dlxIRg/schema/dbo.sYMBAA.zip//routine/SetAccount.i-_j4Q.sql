-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SetAccount]

	@typeDoc varchar(100),
	@transid int,
	@companyid nvarchar(50)
AS
BEGIN

	SET NOCOUNT ON;

	declare @accountID varchar(50);
	
			IF(LOWER(@typeDoc)='payment' )
	BEGIN
	
	SELECT @accountID = accountid
						FROM            Supplier
						WHERE        (id = (SELECT        account
											FROM            Payment
											WHERE        (id = @transid)))
	UPDATE Payment set AccountingAccount = @accountID WHERE id = @transid;
	END
			IF(Lower(@typeDoc)='settlement' )
	BEGIN
	
	SELECT @accountID = accountid
						FROM            Customer
						WHERE        (id = (SELECT        account
											FROM            Settlement
											WHERE        (id = @transid)))
	UPDATE Settlement set AccountingAccount = @accountID WHERE id = @transid;
	END
			IF(Lower(@typeDoc)='vendorinvoice' )
	BEGIN
	
	SELECT @accountID = accountid
						FROM            Supplier
						WHERE        (id = (SELECT        account
											FROM            VendorInvoice
											WHERE        (id = @transid)))
	UPDATE VendorInvoice set AccountingAccount = @accountID WHERE id = @transid;
	END
			IF(Lower(@typeDoc)='customerinvoice' )
	BEGIN
	
	SELECT @accountID = accountid
						FROM            Customer
						WHERE        (id = (SELECT        account
											FROM            CustomerInvoice
											WHERE        (id = @transid)))
	UPDATE CustomerInvoice set AccountingAccount = @accountID WHERE id = @transid;
	END

	RETURN @@ROWCOUNT

END
go

